from django.apps import AppConfig


class AppproduccionConfig(AppConfig):
    name = 'appProduccion'
